export const environment = {
  production: true,
  pathApi: 'http://epicode.online/epicodebeservice_v2',
  adminToken: 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhZG1pbiIsImlhdCI6MTY0OTgzOTQ5NiwiZXhwIjoxNjQ5OTI1ODk2fQ.kDt8cUziHe1Y_0wyhRwBYTVSq2NDDKbGU-bkBHBiny5qiJtgYKN50pZjx8Wpqs04OdF9qy_aAAlM2OQQUZRVLw',
  adminTenant:'fe_0122a'
};
