import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/service/auth.service';
@Component({
  selector: 'app-navbar',
  template: `
    <div class="container d-flex justify-content-center"  >
      <header
        id="navbar"
        class="navbar navbar-light sticky-top flex-nowrap p-0 "
      >
        <nav class="navbar navbar-expand " >
          <ul class="navbar-nav">
            <li class="nav-item" >
              <a
                class="nav-link active"
                aria-current="page"
                [routerLink]="['/']"
                routerLinkActive="active"
                [routerLinkActiveOptions]="{ exact: true }"
                *ngIf="!isLoggedUser()"
                >Home</a
              >
            </li>
            <li class="nav-item">
              <a
                class="nav-link"
                [routerLink]="['/login']"
                routerLinkActive="active"
                *ngIf="!isLoggedUser()"
                >Login</a
              >
            </li>
            <li class="nav-item">
              <a
                class="nav-link"
                [routerLink]="['/registrati']"
                routerLinkActive="active"
                *ngIf="!isLoggedUser()"
                >Registrati</a
              >
            </li>
            <li class="nav-item">
              <a
                class="nav-link"
                [routerLink]="['/utenti']"
                routerLinkActive="active"
                *ngIf="isLoggedUser()"
                >Utenti</a
              >
            </li>
            <li class="nav-item">
              <a
                class="nav-link"
                [routerLink]="['/clienti']"
                routerLinkActive="active"
                *ngIf="isLoggedUser()"
                >Clienti</a
              >
            </li>
            <li class="nav-item">
              <a
                class="nav-link"
                [routerLink]="['/fatture']"
                routerLinkActive="active"
                *ngIf="isLoggedUser()"
                >Fatture</a
              >
            </li>
          </ul>
        </nav>
        <div class="navbar-nav">
          <div class="nav-item text-nowrap">
            <a
              class="nav-link px-3 btn btn-danger m-2"
              *ngIf="isLoggedUser()"
              (click)="Logout()"
              >Logout</a
            >
          </div>
        </div>
      </header>
    </div>
  `,
  styles: [],
})
export class NavbarComponent implements OnInit {
  constructor(private authSrv: AuthService) {}

  isLogged: any;

  ngOnInit(): void {
    this.isLogged = localStorage.getItem('utente');
    console.log(
      'localStorage.getItem("utente");',
      localStorage.getItem('utente')
    );
  }

  isLoggedUser(): boolean {
    return localStorage.getItem('utente') !== null;
  }

  Logout() {
    this.authSrv.logout();
  }
}
