import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  template: `
    <div
      id="contenitore1"
      class="container py-3 mb-10 w-100 justify-content-center text-center"
    >
      <div class="container m-5 ">
        <div
          id="gest"
          class="d-flex flex-row-reverse w-100 p-2 justify-content-center"
        >
          <div class="w-50 mt-5 py-5">
            <div class="text-center">
              <div class="text-start p-1 d-flex justify-content-center">
                <span
                  class="btn btn-outline-primary m-1 text-dark "
                  [routerLink]="['/login']"
                  routerLinkActive="active"
                  >Accedi</span
                >
                <span
                  class="btn btn-outline-success m-1 text-dark"
                  [routerLink]="['/registrati']"
                  routerLinkActive="active"
                  >Registrati</span
                >
              </div>
              <p class="p-3">
                Più informazioni sui clienti: vendi di più, offri un servizio
                migliore.
              </p>
            </div>
          </div>
          <div>
            <div id="image"></div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [
    `
      #contenitore1 {
        height: 35%;
        border-radius: 20px;
        margin-top: 30px;
      }

      #image {
        height: 500px;
        width: 500px;
        background-image: url('img/immagine.png');
        background-size: contain;
        background-repeat: no-repeat;
        border-radius: 5px;
      }
      #gest {
        height: 400px;
      }
    `,
  ],
})
export class HomeComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
