import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/service/auth.service';
import { User } from 'src/app/models/user';

@Component({
  selector: 'app-utenti',
  template: `
    <div class="container cnt-utenti">
      <table class="table">
        <thead>
          <tr>
            <th scope="col" class="id">Id</th>
            <th scope="col" class="user">Username</th>
            <th scope="col" class="email">Email</th>
            <th scope="col" class="role">Roles</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let utente of utenti; let i = index">
            <th scope="row" class="id">{{ utente.id }}</th>
            <td class="user">{{ utente.username }}</td>
            <td class="emails">{{ utente.email }}</td>
            <td *ngFor="let item of utente.roles" class="roles">{{ item.roleName }}</td>
          </tr>
        </tbody>
      </table>
      <div class="d-flex justify-content-center">
      <nav aria-label="Page navigation">
        <ul class="pagination">
          <li class="page-item" *ngIf="!response.first">
            <a class="page-link" (click)="cambiaPag(response.number - 1)"
              >Previous</a
            >
          </li>
          <li class="page-item" *ngFor="let pag of numP; let p = index">
            <a class="page-link" (click)="cambiaPag(p)">{{ p + 1 }}</a>
          </li>
          <li class="page-item" *ngIf="!response.last">
            <a class="page-link" (click)="cambiaPag(response.number + 1)"
              >Next</a
            >
          </li>
        </ul>
      </nav>
      </div>
    </div>
  `,
  styles: [`
  .id,.emails,.email,.user,.role,.roles{
    text-align: center;
  }
  .id{
    color:orange;
  }
  .emails{
    color:green;
  }
  .email{color:lightgreen}
  .roles{
    color:darkred;
  }
  .user{color:blue}
  .role{color:red}
  .cnt-utenti{
    margin-top: 20px;
    max-width: 1020px;
    border: 1px solid #ccc;
    padding: 50px;
  }
  `],
})
export class UtentiComponent implements OnInit {
  constructor(private authSrv: AuthService) {}

  utenti!: Array<User>;
  response!: any;
  pagCorr: any;
  numP: any;

  ngOnInit() {
    this.authSrv.getAll(0).subscribe((c) => {
      this.response = c;
      console.log(this.response);
      this.utenti = this.response.content;
      const numP = Array(this.response.totalPages);
      this.numP = numP;
    });
  }

  cambiaPag(page: number) {
    this.authSrv.getAll(page).subscribe((c) => {
      console.log(page);
      // console.log(c);
      this.response = c;
      this.utenti = this.response.content;
      this.pagCorr = page;
    });
  }
}
