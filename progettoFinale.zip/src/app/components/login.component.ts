import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/service/auth.service';
import { User } from 'src/app/models/user';

@Component({
  selector: 'app-login',
  template: `
    <div class="container w-50">
      <div class="m-5 p-3 text-dark">
        <form #form="ngForm" (ngSubmit)="login(form)">
          <div class="mb-3">
            <label for="username">Username *</label>
            <input
              type="text"
              id="username"
              class="form-control"
              ngModel
              name="username"
            />
          </div>
          <div class="mb-3">
            <label for="password">Password *</label>
            <div class="input-group">
              <input
                type="password"
                id="password"
                class="form-control"
                ngModel
                name="password"
              />
              <button
                for="password"
                class="btn btn-secondary"
                (click)="showPwd()"
                *ngIf="!showPass"
              >
                <svg
                xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  class="bi bi-eye-fill"
                  viewBox="0 0 16 16"
                >
                  <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z" />
                  <path
                    d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8zm8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z"
                  />
                </svg>
              </button>
              <button
                for="password"
                class="btn btn-secondary"
                (click)="showPwd()"
                *ngIf="showPass"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  class="bi bi-eye-slash-fill"
                  viewBox="0 0 16 16"
                >
                  <path
                    d="m10.79 12.912-1.614-1.615a3.5 3.5 0 0 1-4.474-4.474l-2.06-2.06C.938 6.278 0 8 0 8s3 5.5 8 5.5a7.029 7.029 0 0 0 2.79-.588zM5.21 3.088A7.028 7.028 0 0 1 8 2.5c5 0 8 5.5 8 5.5s-.939 1.721-2.641 3.238l-2.062-2.062a3.5 3.5 0 0 0-4.474-4.474L5.21 3.089z"
                  />
                  <path
                    d="M5.525 7.646a2.5 2.5 0 0 0 2.829 2.829l-2.83-2.829zm4.95.708-2.829-2.83a2.5 2.5 0 0 1 2.829 2.829zm3.171 6-12-12 .708-.708 12 12-.708.708z"
                  />
                </svg>
              </button>
            </div>
          </div>
          <div class="d-flex justify-content-start mt-4">
            <button type="submit" class="btn btn-success">Login</button>

          </div>
          <p class="text-muted">Se non hai ancora un account, <a class="btn text-primary" routerLink="/registrati">Registrati</a></p>
        </form>
      </div>
    </div>
  `,
  styles: [`

  `],
})
export class LoginComponent implements OnInit {
  constructor(private authSrv: AuthService, private router: Router) {}

  showPass = false;

  item!: any;
  users!: User;

  ngOnInit(): void {
    localStorage.getItem('utente');
    console.log(
      'localStorage.getItem("utente")',
      localStorage.getItem('utente')
    );
  }
  showPwd() {
    var input = document.getElementById('password') as HTMLInputElement;
    if (input.type === 'password') {
      input.type = 'text';
      this.showPass = true;
    } else {
      input.type = 'password';
      this.showPass = false;
    }
  }

  login(form: NgForm) {
    console.log(form.value);
    this.item = form.value;
    this.authSrv.login(this.item).subscribe(
      (res) => {
        console.log(res);
        this.users = res;
        localStorage.setItem('utente', JSON.stringify(this.users));
        this.router.navigate(['/utenti']);
        localStorage.getItem('utente');
      },
      (rej) => {
        alert('Errore nella compilazione dei campi');
      }
    );
  }
}
